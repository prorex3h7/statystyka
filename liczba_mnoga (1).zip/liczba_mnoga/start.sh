#!/bin/bash
app_name="liczba_mnoga"

docker build -t ${app_name} .
docker run -d -p 5000:5000 ${app_name}

