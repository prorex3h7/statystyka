import random

import click
import nltk
from flask import Flask, request, render_template
from flask.cli import with_appcontext

import db_configuration

app = Flask(__name__)
db_configuration.init_app(app)


def predict(data, word_to_predict):
    # wymieszanie danych
    random.shuffle(data)

    # konwersja zbioru danych na zbior cech
    feature_set = [({'last_letter': word[-1]}, plural) for (word, plural) in data]

    # Podzial listy na zbior treningowy i testowy
    train_set, test_set = feature_set[50:], feature_set[:50]

    # trenowanie klasyfikatora naive Bayes, danymi z bazy danych
    classifier = nltk.NaiveBayesClassifier.train(train_set)

    # uzycie klasyfikatora, do przewidzenia odpowiedzi
    return classifier.classify({'last_letter': word_to_predict[-1]})


@click.command('insert-data')
@with_appcontext
def insert_command():
    db = db_configuration.get_db()
    items = []

    file = open('data.csv', 'r', encoding='utf8')
    for line in file:
        text, plural = line.split(',')
        items.append((text.strip(), plural.strip()))

    query = 'INSERT OR IGNORE INTO words (text, plural) VALUES (?, ?)'
    db.executemany(query, items)
    db.commit()

    click.echo('Dane zostały dodane')


app.cli.add_command(insert_command)


@app.route('/', methods=['POST', 'GET'])
def index():
    if request.method == 'POST':
        word_to_predict = request.form['word']
        result = db_configuration.get_db().execute('SELECT * FROM words')
        words = [(word['text'], word['plural']) for word in result]
        is_plural = predict(words, word_to_predict)

    return render_template('index.html', **locals())


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0")
